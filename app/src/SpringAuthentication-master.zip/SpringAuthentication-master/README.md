A simple android application build using JAVA for frontend 
and springboot and MySQL for backend which helps us 
authenticate user based on the data present in our local
MySQL server and also allows user to register as a new user 
into our local database server.
